
/* Disabled by N. Yamaguchi ***
   int Band_Dispersion();
 * ***/

/* Added by N. Yamaguchi ***/
int BandDispersion();
/* ***/
