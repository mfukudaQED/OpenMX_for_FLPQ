/*----------------------------------------------------------------------
  exx_def_openmx.h
----------------------------------------------------------------------*/
#ifndef EXX_DEF_OPENMX_H_INCLUDED
#define EXX_DEF_OPENMX_H_INCLUDED

#ifndef nompi
#define EXX_USE_MPI
#endif

#define EXX_MIX_DM 1

#endif /* EXX_DEF_OPENMX_H_INCLUDED */

