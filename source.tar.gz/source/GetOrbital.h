
void SpeciesString2int(int p, char **SpeName, char **SpeBasis, int **Spe_Num_Basis);
void Classify_OrbNum(int **ClaOrb, char **An2Spe, int Print_AtomInfo);





