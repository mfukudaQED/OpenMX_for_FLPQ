void func_Newton(double *k1, double E1, double *k2, double E2, double *k3, double *E3, double EF, int l, int loopMAX);
