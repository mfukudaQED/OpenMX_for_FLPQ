void EigenValue_Problem(double k1,double k2,double k3, int calc_switch);


