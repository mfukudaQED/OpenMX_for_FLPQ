
void Eigen_HH(dcomplex **ac, double *ko, int n, int EVmax, int ev_flag);
void lapack_dstevx2(INTEGER N, INTEGER EVmax, double *D, double *E, double *W, dcomplex **ev, int ev_flag);

