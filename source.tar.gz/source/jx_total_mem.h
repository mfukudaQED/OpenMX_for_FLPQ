double total_mem;
