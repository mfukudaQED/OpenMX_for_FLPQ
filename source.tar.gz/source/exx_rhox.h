/*----------------------------------------------------------------------
  exx_rhox.h
----------------------------------------------------------------------*/
#ifndef EXX_RHOX_H_INCLUDED
#define EXX_RHOX_H_INCLUDED

void EXX_Output_DM(EXX_t *exx, dcomplex ****exx_DM);
void EXX_Input_DM(EXX_t *exx, dcomplex ****exx_DM);

#endif /* EXX_RHOX_H_INCLULDED */
