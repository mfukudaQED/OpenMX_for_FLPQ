/*----------------------------------------------------------------------
  exx_step2.h
----------------------------------------------------------------------*/
#ifndef EXX_STEP2_H_INCLUDED
#define EXX_STEP2_H_INCLUDED

#include "exx.h"

int EXX_Step2(const EXX_t *exx);

#endif /* EXX_STEP2_H_INCLUDED */
