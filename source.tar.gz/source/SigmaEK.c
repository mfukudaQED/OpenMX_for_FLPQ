void BandDispersion(){
}
void GridCalc(){
}
void FermiLoop(){
}
void MulPOnly(){
}
